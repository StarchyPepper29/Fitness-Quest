import 'package:flutter/material.dart';

class ProductBox extends StatelessWidget {
  final String title;
  final List<Map<String, String>> products;

  const ProductBox({
    Key? key,
    required this.title,
    required this.products,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15.0),
        border: Border.all(
          color: Color.fromRGBO(
              248, 153, 80, 1), // Border color: rgba(248,153,80,255)
          width: 2.0,
        ),
        color: Colors.white,
      ),
      padding: EdgeInsets.all(16.0),
      margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize:
            MainAxisSize.min, // Adjusts the column size to fit its children
        children: [
          // Title with orange color
          Padding(
            padding: EdgeInsets.only(bottom: 8.0),
            child: Text(
              title,
              style: TextStyle(
                fontSize: 40.0,
                fontFamily:
                    'Aristotellica', // Assuming 'Aristotellica' is a custom font
                fontWeight: FontWeight.w600,
                color: Color.fromRGBO(
                    255, 131, 96, 1), // Title color: rgba(255,131,96,255)
              ),
            ),
          ),
          // Divider below the title
          Container(
            height: 2.4,
            color: Color.fromRGBO(
                248, 153, 80, 1), // Divider color: rgba(248,153,80,255)
            margin: EdgeInsets.only(bottom: 8.0),
          ),
          // Products grid
          GridView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, // 3 columns
              crossAxisSpacing: 16.0,
              mainAxisSpacing: 16.0,
            ),
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              return GestureDetector(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        content: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              height: 100.0,
                              child: Image.asset(
                                product['imagePath']!,
                                fit: BoxFit.cover,
                              ),
                            ),
                            SizedBox(height: 8.0),
                            Text(
                              product['name']!,
                              style: TextStyle(
                                fontSize: 18.0,
                                fontFamily: 'Pines',
                                color: Color.fromRGBO(68, 74, 79, 1),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 4.0),
                            Text(
                              '\$${product['price']}',
                              style: TextStyle(
                                fontSize: 14.0,
                                fontFamily: 'Pines',
                                color: Color.fromRGBO(68, 74, 79, 1),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 8.0),
                            Text(
                              product['description']!,
                              style: TextStyle(
                                fontSize: 14.0,
                                fontFamily: 'Pines',
                                color: Color.fromRGBO(68, 74, 79, 1),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 16.0),
                            ElevatedButton(
                              onPressed: () {
                                // Implement your buy logic here
                                // For now, just close the dialog
                                Navigator.of(context).pop();
                              },
                              child: Text('Buy'),
                            ),
                          ],
                        ),
                        actions: <Widget>[
                          IconButton(
                            icon: Icon(Icons.close),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                        ],
                      );
                    },
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15.0),
                    border: Border.all(
                      color: Color.fromRGBO(248, 153, 80, 1),
                      width: 2.0,
                    ),
                    color: Colors.white,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 100.0,
                        child: Image.asset(
                          product['imagePath']!,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(height: 8.0),
                      Text(
                        product['name']!,
                        style: TextStyle(
                          fontSize: 18.0,
                          fontFamily: 'Pines',
                          color: Color.fromRGBO(68, 74, 79, 1),
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 4.0),
                      Text(
                        '\$${product['price']}',
                        style: TextStyle(
                          fontSize: 14.0,
                          fontFamily: 'Pines',
                          color: Color.fromRGBO(68, 74, 79, 1),
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class ProductPage extends StatelessWidget {
  final String productName;

  const ProductPage({
    Key? key,
    required this.productName,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(productName),
      ),
      body: Center(
        child: Text('Details for $productName'),
      ),
    );
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final List<Map<String, String>> products = [
    {
      'name': 'Product 1',
      'imagePath': 'assets/images/product1.png',
      'price': '10.00',
      'description': 'Description for Product 1'
    },
    {
      'name': 'Product 2',
      'imagePath': 'assets/images/product2.png',
      'price': '20.00',
      'description': 'Description for Product 2'
    },
    // Add more products here
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Column(
          children: [
            Expanded(
              child: ProductBox(title: 'Products', products: products),
            ),
          ],
        ),
      ),
    );
  }
}
